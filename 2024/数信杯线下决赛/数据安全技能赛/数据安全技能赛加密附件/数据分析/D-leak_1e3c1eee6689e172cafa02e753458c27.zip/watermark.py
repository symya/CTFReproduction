import cv2
import copy
import random
import numpy as np
from numpy.linalg import svd
from pywt import dwt2, idwt2

class WaterMark:
    def __init__(self, filename = None, seed = 'thisisdefaultpassword'):

        assert filename is not None
        random.seed(seed)
        self.block_shape = np.array([4, 4])
        self.password = random.getrandbits(24)
        self.d1, self.d2 = 36, 20
        self.img, self.img_YUV = None, None
        self.ca, self.hvd, = [np.array([])] * 3, [np.array([])] * 3
        self.ca_block = [np.array([])] * 3
        self.ca_part = [np.array([])] * 3
        self.wm_size, self.block_num = 0, 0
        self.alpha = None
        self.wm_num = 1
        self.wm_bit = None

        img = cv2.imread(filename, flags=cv2.IMREAD_UNCHANGED)
        assert img is not None, f"image file '{filename}' not read"
        self.read_img_arr(img=img)

    def add_mark(self, wm_content):
        byte = bin(int(wm_content.encode('utf-8').hex(), base=16))[2:]
        self.wm_bit = (np.array(list(byte)) == '1')

        np.random.RandomState(self.wm_num).shuffle(self.wm_bit)

        self.wm_size = self.wm_bit.size

    def init_block_index(self):
        self.block_num = self.ca_block_shape[0] * self.ca_block_shape[1]
        assert self.wm_size < self.block_num, IndexError(f'A maximum of {self.block_num / 1000}kb of information can be embedded, which is less than the {self.wm_size / 1000}kb of watermark information.')

        self.part_shape = self.ca_block_shape[:2] * self.block_shape
        self.block_index = [(i, j) for i in range(self.ca_block_shape[0]) for j in range(self.ca_block_shape[1])]

    def read_img_arr(self, img):
        if img.shape[2] == 4:
            if img[:, :, 3].min() < 255:
                self.alpha = img[:, :, 3]
                img = img[:, :, :3]

        self.img = img.astype(np.float32)
        self.img_shape = self.img.shape[:2]

        self.img_YUV = cv2.copyMakeBorder(cv2.cvtColor(self.img, cv2.COLOR_BGR2YUV), 0, self.img.shape[0] % 2, 0, self.img.shape[1] % 2, cv2.BORDER_CONSTANT, value=(0, 0, 0))

        self.ca_shape = [(i + 1) // 2 for i in self.img_shape]
        self.ca_block_shape = (self.ca_shape[0] // self.block_shape[0], self.ca_shape[1] // self.block_shape[1], self.block_shape[0], self.block_shape[1])
        strides = 4 * np.array([self.ca_shape[1] * self.block_shape[0], self.block_shape[1], self.ca_shape[1], 1])

        for channel in range(3):
            self.ca[channel], self.hvd[channel] = dwt2(self.img_YUV[:, :, channel], 'haar')
            self.ca_block[channel] = np.lib.stride_tricks.as_strided(self.ca[channel].astype(np.float32), self.ca_block_shape, strides)

    def block_add_wm(self, arg):
        block, shuffler, i = arg

        wm_1 = self.wm_bit[i % self.wm_size]
        block_dct = cv2.dct(block)

        block_dct_shuffled = block_dct.flatten()[shuffler].reshape(self.block_shape)
        u, s, v = svd(block_dct_shuffled)
        s[0] = (s[0] // self.d1 + 1 / 4 + 1 / 2 * wm_1) * self.d1
        if self.d2:
            s[1] = (s[1] // self.d2 + 1 / 4 + 1 / 2 * wm_1) * self.d2

        block_dct_flatten = np.dot(u, np.dot(np.diag(s), v)).flatten()
        block_dct_flatten[shuffler] = block_dct_flatten.copy()
        return cv2.idct(block_dct_flatten.reshape(self.block_shape))

    def save(self, filename = None):
        self.init_block_index()

        embed_ca = copy.deepcopy(self.ca)
        embed_YUV = [np.array([])] * 3

        self.idx_shuffle = np.random.RandomState(self.password).random(size=(self.block_num, self.block_shape[0] * self.block_shape[1])).argsort(axis=1)

        for channel in range(3):
            tmp = list(map(self.block_add_wm, [(self.ca_block[channel][self.block_index[i]], self.idx_shuffle[i], i) for i in range(self.block_num)]))

            for i in range(self.block_num):
                self.ca_block[channel][self.block_index[i]] = tmp[i]

            self.ca_part[channel] = np.concatenate(np.concatenate(self.ca_block[channel], 1), 1)
            embed_ca[channel][:self.part_shape[0], :self.part_shape[1]] = self.ca_part[channel]
            embed_YUV[channel] = idwt2((embed_ca[channel], self.hvd[channel]), "haar")

        embed_img_YUV = np.stack(embed_YUV, axis=2)
        embed_img_YUV = embed_img_YUV[:self.img_shape[0], :self.img_shape[1]]
        embed_img = cv2.cvtColor(embed_img_YUV, cv2.COLOR_YUV2BGR)
        embed_img = np.clip(embed_img, a_min=0, a_max=255)

        if self.alpha is not None:
            embed_img = cv2.merge([embed_img.astype(np.uint8), self.alpha])

        cv2.imwrite(filename=filename, img=embed_img)
        return embed_img


if __name__ == '__main__':
    bwm = WaterMark()
    bwm.read_img('test.png')
    bwm.read_wm(water_text, mode='str')
    bwm.embed('out.png')