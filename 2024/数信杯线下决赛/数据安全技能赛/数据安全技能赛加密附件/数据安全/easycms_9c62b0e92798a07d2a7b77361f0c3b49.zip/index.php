<?
if (!file_exists('core/config.php')) {
	header('Location: install.php');
	exit(1);
}
require_once 'core/bootstrap.php';