<?
/**
 * @template One Column
 * @author Cocoon Design
 * @copyright 2012 (c) Cocoon Design
 */	
?>

<h1><? theTitle() ?></h1>
<? theContent() ?>