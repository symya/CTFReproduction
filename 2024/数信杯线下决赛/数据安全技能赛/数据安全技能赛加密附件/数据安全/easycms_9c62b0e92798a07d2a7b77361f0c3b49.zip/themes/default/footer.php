<footer>
	Copyright &copy;<? echo date('Y') ?> Welcome - <? cmsPage('Admin', 'cms-admin') ?><br />
</footer>
</div> <!-- END CONTAINER -->
</body>
</html>