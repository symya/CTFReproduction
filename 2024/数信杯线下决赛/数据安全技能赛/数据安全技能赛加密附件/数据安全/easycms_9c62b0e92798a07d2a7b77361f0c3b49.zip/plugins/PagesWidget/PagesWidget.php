<?
/**
 * @plugin Pages Widget
 * @author Cocoon Design
 * @authorURI http://www.wearecocoon.co.uk/
 * @description Lists the pages on the site in a widget
 * @copyright 2012 (C) Cocoon Design  
 */
 
 class PagesWidget {

 }