<?
Blog::theCategories();