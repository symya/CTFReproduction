<?

if(!isset($_SESSION['loggedin'])) header('Location: login.php');
else header('Location: dashboard.php');
exit();