<?

class Update {

    private static function xml(){

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://api.p53.ca/get/core/');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($ch);
        curl_close($ch);

        $xml = simplexml_load_string($output);

        return $xml;
    }

    public static function checkUpdate(){
        $xml = self::xml();
        $curver = CANDYVERSION;

        foreach ($xml->channel->item as $item) {
            $newver = $item->version;

            if(version_compare($curver, $newver, '>=')){
                $return = false;
            } else {
                $return = "<p class='message notice update'>CMS v$newver is available, you have v$curver. <a href='dashboard.php?page=update'>Learn More</a></p>";
                break;
            }
        }

        return $return;
    }
	
	public static function getChangelog(){
		
		$xml = self::xml();
		
		$curver = CANDYVERSION;
		
		foreach ($xml->channel->item as $item) {
			$newver = $item->version;
			
			if(!version_compare($curver, $newver, '>=')){
				$version = 'CMS v'.$item->version; 
				$changelog = $item->changelog;
				$updateurl = $item->updateurl;
				$downloadurl = $item->downloadurl;
				break;
			}
		}
	
		
		if (self::checkUpdate() == false) {
			echo '<p class="leadin">CMS is up to date!</p>';
		} else {
			echo "<h3>$version</h3>";
			echo '<p class="leadin">This update includes the following:</p>';
			echo $changelog;
			echo "<a href='$downloadurl' class='button dl-btn'>Download from Github</a>";
			echo "<a href='dashboard.php?page=update&update' class='button'>Update Automatically</a>";
		}
		
	}
	
	public static function updateUrl(){
	
		$xml = self::xml();
		
		$curver = CANDYVERSION;
		
		foreach ($xml->channel->item as $item) {
			$newver = $item->version;
			
			if(version_compare($curver, $newver, '>=')){
				$return = false;
			} else {
				$return = $item->updateurl;
				break;
			}
		}
		
		return $return;
		
	}

}

?>