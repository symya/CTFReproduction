<?



define('CANDYVERSION', '0.1');

# This is set to MySQL by default but can be changed to your DB of choice
define('DB_DRIVER', 'mysql');

define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'pasword');
define('DB_NAME', 'database');
define('DB_PREFIX', 'cms_');

define('SALT', '873hjcbdi1kammcvjnj0u3jn');

define('CMS_PATH', $_SERVER['DOCUMENT_ROOT'].'/cms/');

define('URL_PATH', '/cms/');

define('THEME_PATH', CMS_PATH.'themes/');

define('THEME_URL', URL_PATH.'themes/');

define('PLUGIN_PATH', CMS_PATH.'plugins/');

define('PLUGIN_URL', URL_PATH.'plugins/');